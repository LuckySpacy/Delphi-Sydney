# generics.collections
FreePascal Generics.Collections library (TList, TDictionary, THashMap and more...)
